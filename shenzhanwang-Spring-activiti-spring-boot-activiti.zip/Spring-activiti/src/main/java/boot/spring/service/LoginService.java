package boot.spring.service;


public interface LoginService {
	String getpwdbyname(String name);
}
